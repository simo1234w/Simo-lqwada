#!/usr/bin/env bash
# Build a distributable zip: ./scripts/pack.sh  ->  dist/simo-lqwada-<version>.zip
set -euo pipefail
cd "$(dirname "$0")/.."
version=$(grep -m1 '"version"' manifest.json | sed 's/.*: *"\(.*\)".*/\1/')
mkdir -p dist
out="dist/simo-lqwada-${version}.zip"
rm -f "$out"
zip -r "$out" manifest.json src popup icons LICENSE README.md
echo "Created $out"

"""Generate the extension icons (a lens on a teal rounded square). Run: python3 scripts/make_icons.py"""
from PIL import Image, ImageDraw

def icon(size):
    s = size * 8
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=(14, 124, 134, 255))
    c = s / 2
    for r, col in ((0.31, (240, 249, 250, 255)), (0.23, (22, 34, 46, 255)), (0.13, (79, 195, 205, 255))):
        d.ellipse([c - s * r, c - s * r, c + s * r, c + s * r], fill=col)
    h = s * 0.045  # specular highlight
    d.ellipse([c - s * 0.1 - h, c - s * 0.1 - h, c - s * 0.1 + h, c - s * 0.1 + h], fill=(255, 255, 255, 255))
    return img.resize((size, size), Image.LANCZOS)

for n in (16, 32, 48, 128):
    icon(n).save(f"icons/icon-{n}.png")
print("icons written")

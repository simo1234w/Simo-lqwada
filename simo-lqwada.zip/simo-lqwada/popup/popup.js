/* simo-lqwada popup: reads and writes settings in extension storage. */
(() => {
  'use strict';

  const api = globalThis.browser ?? globalThis.chrome;
  const note = document.getElementById('note');
  const defaultNote = note.textContent;

  const inputs = [...document.querySelectorAll('[data-key]')];

  (async () => {
    let saved = {};
    try { saved = await api.storage.local.get(SIMO_DEFAULTS); } catch (err) { /* use defaults */ }
    const values = { ...SIMO_DEFAULTS, ...saved };

    for (const input of inputs) {
      const value = values[input.dataset.key];
      if (input.type === 'checkbox') input.checked = !!value;
      else input.value = String(value);

      input.addEventListener('change', async () => {
        let next = input.type === 'checkbox' ? input.checked : input.value;
        if (input.dataset.type === 'number') next = Number(next);
        try { await api.storage.local.set({ [input.dataset.key]: next }); }
        catch (err) { showNote('Couldn’t save that setting. Try again.', true); }
      });
    }
  })();

  document.getElementById('open').addEventListener('click', async () => {
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      if (!tab || tab.id == null) throw new Error('no tab');
      await api.tabs.sendMessage(tab.id, { type: 'simo-lqwada:open-panel' });
      window.close();
    } catch (err) {
      showNote('This page can’t be used with the extension. Open a regular website, then reload it once after installing.', true);
    }
  });

  function showNote(text, isError) {
    note.textContent = text || defaultNote;
    note.classList.toggle('error', !!isError);
  }
})();

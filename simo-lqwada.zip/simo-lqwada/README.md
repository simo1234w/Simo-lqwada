# simo-lqwada

A lightweight virtual camera for your browser. Pick a video file on your computer and any website that asks for your webcam gets that video instead.

- **Any length.** The file plays straight from disk, so a 5-second loop and a 3-hour recording work the same. Looping is on by default.
- **High quality.** Up to 1080p at up to 60 fps, scaled to fill whatever size the site asks for.
- **Lightweight.** No dependencies, no build step, about 25 KB of code. It does nothing until a site asks for a camera.
- **Private.** No network requests, no analytics, no accounts. Your video never leaves your computer.
- **Broad support.** Chrome, Edge, Brave, Opera, Vivaldi, Arc and other Chromium browsers (111+), and Firefox 128+.

## Install

### Chrome, Edge, Brave, Opera, Vivaldi, Arc

1. Download or clone this repository and unzip it if needed.
2. Open `chrome://extensions` (Edge: `edge://extensions`, Brave: `brave://extensions`).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the folder that contains `manifest.json`.
5. Pin the simo-lqwada icon from the puzzle-piece menu if you want quick access.

### Firefox (128 or newer)

1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…** and select `manifest.json`.
3. Temporary add-ons are removed when Firefox restarts. For a permanent install, sign the extension through [addons.mozilla.org](https://addons.mozilla.org/developers/).

## Use it

1. Open any site that uses your camera and reload the page once after installing.
2. When the site asks for the camera, a small **simo-lqwada** panel appears in the bottom-right corner.
3. Click **Choose video…** (or drop a file on the panel). MP4 (H.264) and WebM play in every supported browser.
4. The site now sees your video as the camera. Pause, swap or remove the video from the same panel.

The toolbar popup controls the rest:

| Setting | What it does |
| --- | --- |
| On/off switch | Turns the virtual camera on or off for new camera requests. |
| Replace camera | **For every site** swaps any camera request. **Only when I pick it** leaves your real camera alone unless the site lets you choose "simo-lqwada Virtual Camera" from its camera list. |
| Quality | Match the site's request, or force 480p, 720p or 1080p. |
| Frame rate | Default frame rate when the site doesn't specify one. |
| Sound | Use your real microphone (default), the video's own audio, or silence. |
| Loop / Mirror | Restart the video when it ends, or flip the picture. Both apply live. |

"Remember on this site" in the panel stores the video in that site's browser storage so it comes back after a reload. Use **Remove saved video** to delete it.

## Try it

Serve the test page and open it:

```bash
cd test
python3 -m http.server 8080
# then visit http://localhost:8080
```

Click **Start camera**. The page shows the track label, resolution and a running timer, so you can confirm the stream keeps going past 30 seconds.

If you open `test/index.html` straight from disk in Chrome, enable **Allow access to file URLs** for the extension on its card in `chrome://extensions`.

## How it works

```
manifest.json        Manifest V3. Registers two content scripts and the popup.
src/inject.js        Runs in the page's own JS world. Wraps getUserMedia and enumerateDevices,
                     draws the video onto a canvas and returns canvas.captureStream() as the camera.
src/content.js       Runs in the extension's isolated world. Relays settings and popup commands
                     to inject.js using DOM events carrying JSON strings.
src/defaults.js      Setting defaults shared by the content script and popup.
popup/               Toolbar popup (HTML, CSS, JS).
icons/               Extension icons (regenerate with scripts/make_icons.py).
test/index.html      Local test page.
scripts/pack.sh      Builds dist/simo-lqwada-<version>.zip.
```

The virtual track is labelled "simo-lqwada Virtual Camera" in `track.label` and in the device list, and the on-page panel is always visible while a virtual stream is active.

## Known limits

- **Background tabs.** Browsers slow down timers in hidden tabs. Calls and recordings normally keep the tab exempt, but if the picture stutters when you switch tabs, keep the call in its own window.
- **Sites that use cameras inside Web Workers or native apps** (some desktop-app wrappers) can't be intercepted by a browser extension.
- **Strict Content Security Policy pages** are fine, since nothing is injected as inline script. Pages that block extensions entirely (the browser's own settings pages and extension stores) can't be used.
- **Embedded iframes** each have their own video selection. The panel is hidden in very small frames.
- **Safari** isn't supported yet. It needs conversion with Xcode's `safari-web-extension-converter`.
- **Video formats** depend on what your browser can decode. MKV and some HEVC files won't play in every browser.

## Package for the stores

```bash
./scripts/pack.sh   # creates dist/simo-lqwada-1.0.0.zip
```

For Firefox's add-on site, add `data_collection_permissions` under `browser_specific_settings.gecko` in `manifest.json` (this extension collects nothing).

## Responsible use

Use simo-lqwada for streaming, demos, testing video apps, privacy, and fun. Don't use it to impersonate someone, deceive other people, or get around identity checks or exam proctoring. Many services prohibit that, and it may be illegal where you live.

## License

MIT. See [LICENSE](LICENSE).

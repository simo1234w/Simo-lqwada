/* Shared defaults, loaded by the content script and the popup. */
// eslint-disable-next-line no-var
var SIMO_DEFAULTS = Object.freeze({
  enabled: true,      // master switch
  mode: 'always',     // 'always' = replace any camera request | 'select' = only when the virtual device is picked
  mirror: false,      // flip the picture horizontally
  loop: true,         // restart the video when it ends (so a clip of any length can run indefinitely)
  audio: 'mic',       // 'mic' = real microphone | 'video' = the video's own sound | 'silent'
  resolution: 'auto', // 'auto' = follow the website's request | '480' | '720' | '1080'
  fps: 30             // default frame rate when the website doesn't ask for one
});

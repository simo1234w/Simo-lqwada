/*
 * simo-lqwada: content script (isolated world).
 *
 * The page script (inject.js) runs in the page's own JavaScript world so it can
 * replace navigator.mediaDevices.getUserMedia. That world cannot use extension
 * APIs, so this script relays settings and commands to it through DOM events.
 * Only plain JSON strings cross the boundary.
 */
(() => {
  'use strict';

  const api = globalThis.browser ?? globalThis.chrome;
  const NS = 'simo-lqwada';
  let current = { ...SIMO_DEFAULTS };

  const push = () => {
    window.dispatchEvent(new CustomEvent(`${NS}:settings`, { detail: JSON.stringify(current) }));
  };

  // The page script announces itself; answer with the current settings.
  window.addEventListener(`${NS}:ready`, push);

  (async () => {
    try {
      current = { ...SIMO_DEFAULTS, ...(await api.storage.local.get(SIMO_DEFAULTS)) };
    } catch (err) {
      /* fall back to defaults */
    }
    push();
  })();

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const [key, change] of Object.entries(changes)) {
      if (key in SIMO_DEFAULTS) current[key] = change.newValue ?? SIMO_DEFAULTS[key];
    }
    push();
  });

  // Commands from the popup (for example "open the video panel").
  api.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === `${NS}:open-panel`) {
      window.dispatchEvent(new CustomEvent(`${NS}:command`, { detail: 'panel' }));
    }
  });
})();

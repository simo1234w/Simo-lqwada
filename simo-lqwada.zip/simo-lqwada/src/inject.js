/*
 * simo-lqwada: virtual camera (runs in the page's own JavaScript world).
 *
 * What it does
 *  - Wraps navigator.mediaDevices.getUserMedia. When a site asks for a camera,
 *    it returns a MediaStream built from a local video file instead.
 *  - Adds a clearly named "simo-lqwada Virtual Camera" entry to enumerateDevices().
 *  - Draws the video onto a canvas and captures that canvas as the camera track,
 *    so the picture can be scaled, cropped and mirrored to whatever the site asked for.
 *  - Plays the file straight from disk through a blob URL, so there is no length
 *    limit and the whole file is never loaded into memory.
 *
 * Nothing here talks to the network.
 */
(() => {
  'use strict';

  const NS = 'simo-lqwada';
  const LABEL = 'simo-lqwada Virtual Camera';
  const DEVICE_ID = 'simo-lqwada-virtual-camera';
  const GROUP_ID = 'simo-lqwada-group';

  if (window.__simoLqwada) return;
  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') return;
  Object.defineProperty(window, '__simoLqwada', { value: true });

  /* ------------------------------------------------------------------ settings */

  const settings = {
    enabled: true, mode: 'always', mirror: false, loop: true,
    audio: 'mic', resolution: 'auto', fps: 30
  };

  // getUserMedia waits briefly for the first settings message so a call made
  // right at page load still respects what the user chose in the popup.
  let markSettingsReady;
  const settingsReady = new Promise((resolve) => { markSettingsReady = resolve; });
  setTimeout(markSettingsReady, 500);

  window.addEventListener(`${NS}:settings`, (e) => {
    try {
      Object.assign(settings, JSON.parse(e.detail));
      applySettings();
    } catch (err) { /* ignore malformed messages */ }
    markSettingsReady();
  });
  window.addEventListener(`${NS}:command`, (e) => {
    if (e.detail === 'panel') ui.show({ expand: true, force: true });
  });

  /* ------------------------------------------------------------- video source */

  const vid = document.createElement('video');
  vid.muted = true;
  vid.playsInline = true;
  vid.preload = 'auto';
  vid.setAttribute('playsinline', '');

  const src = { name: '', url: '', ready: false, saved: false, userActive: false };

  function syncMute() {
    // Only unmute when the video's sound is routed into the audio graph (never to the speakers).
    vid.muted = !(audio.videoDest && settings.audio === 'video' && src.userActive);
  }

  function applySettings() {
    vid.loop = !!settings.loop;
    syncMute();
    ui.update();
  }

  async function playVideo() {
    try { await vid.play(); } catch (err) { /* autoplay blocked; the next user gesture retries */ }
  }

  function onFirstGesture() {
    src.userActive = true;
    if (audio.ctx && audio.ctx.state === 'suspended') audio.ctx.resume().catch(() => {});
    syncMute();
    if (src.ready && vid.paused && !vid.ended && !userPaused) playVideo();
  }
  let userPaused = false;
  ['pointerdown', 'keydown', 'touchstart'].forEach((t) =>
    window.addEventListener(t, onFirstGesture, { capture: true, once: true, passive: true }));

  ['play', 'pause', 'ended', 'loadeddata'].forEach((t) => vid.addEventListener(t, () => ui.update()));

  async function loadBlob(blob, { name, persist = false } = {}) {
    const url = URL.createObjectURL(blob);
    const prev = src.url;
    try {
      await new Promise((resolve, reject) => {
        const ok = () => { cleanup(); resolve(); };
        const bad = () => { cleanup(); reject(new Error('Your browser can’t play this video format. Try an MP4 (H.264) or WebM file.')); };
        const cleanup = () => { vid.removeEventListener('loadeddata', ok); vid.removeEventListener('error', bad); };
        vid.addEventListener('loadeddata', ok);
        vid.addEventListener('error', bad);
        vid.src = url;
      });
    } catch (err) {
      URL.revokeObjectURL(url);
      if (prev) vid.src = prev; else { vid.removeAttribute('src'); vid.load(); }
      throw err;
    }
    if (prev) URL.revokeObjectURL(prev);
    src.url = url;
    src.name = name || blob.name || 'video';
    src.ready = true;
    userPaused = false;
    vid.loop = !!settings.loop;
    await playVideo();
    if (persist) {
      try { await idbPut({ name: src.name, blob }); src.saved = true; }
      catch (err) { throw new Error('Video loaded, but it couldn’t be saved for this site (storage may be full).'); }
    }
    ui.update();
  }

  /* --------------------------------------------- per-site storage (IndexedDB) */

  const DB_NAME = 'simo-lqwada';
  const STORE = 'kv';
  const openDb = () => new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  async function idb(mode, fn) {
    const db = await openDb();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const req = fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(req && req.result);
        tx.onerror = tx.onabort = () => reject(tx.error);
      });
    } finally { db.close(); }
  }
  const idbGet = () => idb('readonly', (s) => s.get('video'));
  const idbPut = (v) => idb('readwrite', (s) => s.put(v, 'video'));
  const idbDel = () => idb('readwrite', (s) => s.delete('video'));

  let restorePromise = null;
  function ensureRestored() {
    restorePromise = restorePromise || (async () => {
      try {
        const rec = await idbGet();
        if (rec && rec.blob) {
          await loadBlob(rec.blob, { name: rec.name });
          src.saved = true;
        }
      } catch (err) { /* nothing saved, or storage unavailable here */ }
    })();
    return restorePromise;
  }

  /* -------------------------------------------------------------------- audio */

  const audio = { ctx: null, videoDest: null };

  function ensureAudioCtx() {
    if (!audio.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      audio.ctx = new AC();
    }
    if (audio.ctx.state === 'suspended') audio.ctx.resume().catch(() => {});
    return audio.ctx;
  }

  function ensureVideoAudio() {
    const ctx = ensureAudioCtx();
    if (!audio.videoDest) {
      const node = ctx.createMediaElementSource(vid);
      audio.videoDest = ctx.createMediaStreamDestination();
      node.connect(audio.videoDest);
    }
    syncMute();
    return audio.videoDest;
  }

  /* -------------------------------------------------------- canvas -> camera */

  const num = (c) => {
    if (typeof c === 'number') return c;
    if (c && typeof c === 'object') {
      for (const k of ['exact', 'ideal', 'max', 'min']) if (typeof c[k] === 'number') return c[k];
    }
    return undefined;
  };
  const even = (n) => Math.max(2, Math.round(n / 2) * 2);

  function targetSize(vc) {
    let w, h, f;
    if (vc && typeof vc === 'object') { w = num(vc.width); h = num(vc.height); f = num(vc.frameRate); }
    const portrait = !!(w && h && h > w);
    const preset = settings.resolution !== 'auto' ? Number(settings.resolution) : 0;
    if (preset) {
      h = preset; w = Math.round(preset * 16 / 9);
      if (portrait) { const t = w; w = h; h = t; }
    } else if (!w && !h) {
      if (src.ready && vid.videoWidth) { w = vid.videoWidth; h = vid.videoHeight; }
      else { w = 1280; h = 720; }
    } else if (w && !h) h = Math.round(w * 9 / 16);
    else if (h && !w) w = Math.round(h * 16 / 9);
    const k = Math.min(1, 1920 / Math.max(w, h), 1080 / Math.min(w, h));
    const fps = Math.min(60, Math.max(5, Math.round(f || settings.fps || 30)));
    return { w: even(w * k), h: even(h * k), fps };
  }

  function placeholder(ctx, w, h, t) {
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#16222e'); g.addColorStop(1, '#22384a');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const pulse = (Math.sin(t / 450) + 1) / 2;
    ctx.strokeStyle = `rgba(110, 212, 220, ${0.25 + 0.4 * pulse})`;
    ctx.lineWidth = Math.max(2, h * 0.006);
    ctx.beginPath();
    ctx.arc(w / 2, h * 0.42, h * 0.1 * (1 + 0.1 * pulse), 0, Math.PI * 2);
    ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e6eef3';
    ctx.font = `600 ${Math.round(h * 0.05)}px system-ui, sans-serif`;
    ctx.fillText('simo-lqwada', w / 2, h * 0.63);
    ctx.fillStyle = '#9db2c0';
    ctx.font = `${Math.round(h * 0.032)}px system-ui, sans-serif`;
    ctx.fillText('No video selected. Open the simo-lqwada panel to choose one.', w / 2, h * 0.71);
  }

  function paint(ctx, w, h, t) {
    if (src.ready && vid.readyState >= 2 && vid.videoWidth) {
      const vw = vid.videoWidth, vh = vid.videoHeight;
      const s = Math.max(w / vw, h / vh); // cover: fill the frame, crop the overflow
      const dw = vw * s, dh = vh * s;
      ctx.save();
      if (settings.mirror) { ctx.translate(w, 0); ctx.scale(-1, 1); }
      ctx.drawImage(vid, (w - dw) / 2, (h - dh) / 2, dw, dh);
      ctx.restore();
    } else {
      placeholder(ctx, w, h, t);
    }
  }

  function startPipeline(w, h, fps) {
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d', { alpha: false });
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    paint(ctx, w, h, performance.now()); // first frame is ready before the site sees the stream

    const stream = canvas.captureStream(fps);
    const track = stream.getVideoTracks()[0];
    const frameMs = 1000 / fps;
    let last = 0, raf = 0, timer = 0, stopped = false;

    const cancel = () => { cancelAnimationFrame(raf); clearTimeout(timer); };
    const stop = () => { stopped = true; cancel(); document.removeEventListener('visibilitychange', resume); };
    const tick = () => {
      if (stopped) return;
      if (track.readyState === 'ended') return stop();
      const now = performance.now();
      if (now - last >= frameMs - 3) { last = now; paint(ctx, w, h, now); }
      schedule();
    };
    // requestAnimationFrame is paused in background tabs; fall back to a timer there.
    const schedule = () => {
      if (document.hidden) timer = setTimeout(tick, frameMs);
      else raf = requestAnimationFrame(tick);
    };
    const resume = () => { if (!stopped) { cancel(); schedule(); } };
    document.addEventListener('visibilitychange', resume);
    schedule();

    // Be transparent about what this track is.
    const nativeSettings = track.getSettings.bind(track);
    Object.defineProperty(track, 'label', { value: LABEL, configurable: true });
    track.getSettings = () => ({ ...nativeSettings(), deviceId: DEVICE_ID, groupId: GROUP_ID, width: w, height: h, frameRate: fps });

    return stream;
  }

  /* -------------------------------------------------------- API interception */

  const realGUM = md.getUserMedia.bind(md);
  const realEnumerate = typeof md.enumerateDevices === 'function' ? md.enumerateDevices.bind(md) : null;

  function requestedDeviceId(vc) {
    if (!vc || typeof vc !== 'object') return undefined;
    let id = vc.deviceId;
    if (id && typeof id === 'object' && !Array.isArray(id)) id = id.exact ?? id.ideal;
    return Array.isArray(id) ? id[0] : id;
  }

  function shouldVirtualize(constraints) {
    if (!settings.enabled || !constraints || !constraints.video) return false;
    if (requestedDeviceId(constraints.video) === DEVICE_ID) return true;
    return settings.mode === 'always';
  }

  async function virtualGUM(constraints) {
    await ensureRestored();
    const { w, h, fps } = targetSize(constraints.video);

    let audioTrack = null;
    if (constraints.audio) {
      if (settings.audio === 'mic') {
        const mic = await realGUM({ audio: constraints.audio });
        audioTrack = mic.getAudioTracks()[0];
      } else if (settings.audio === 'video') {
        audioTrack = ensureVideoAudio().stream.getAudioTracks()[0].clone();
      } else {
        audioTrack = ensureAudioCtx().createMediaStreamDestination().stream.getAudioTracks()[0];
      }
    }

    const stream = startPipeline(w, h, fps);
    if (audioTrack) stream.addTrack(audioTrack);
    ui.show({ expand: !src.ready });
    return stream;
  }

  function define(obj, name, fn) {
    Object.defineProperty(obj, name, { value: fn, writable: true, configurable: true });
  }

  define(md, 'getUserMedia', async function getUserMedia(constraints) {
    await settingsReady;
    return shouldVirtualize(constraints) ? virtualGUM(constraints) : realGUM(constraints);
  });

  if (realEnumerate) {
    define(md, 'enumerateDevices', async function enumerateDevices() {
      await settingsReady;
      const list = await realEnumerate();
      if (!settings.enabled) return list;
      let info;
      try {
        info = Object.create(MediaDeviceInfo.prototype);
        const json = { deviceId: DEVICE_ID, kind: 'videoinput', label: LABEL, groupId: GROUP_ID };
        for (const [k, v] of Object.entries(json)) Object.defineProperty(info, k, { value: v, enumerable: true });
        Object.defineProperty(info, 'toJSON', { value: () => ({ ...json }) });
      } catch (err) { return list; }
      const out = list.slice();
      const first = out.findIndex((d) => d.kind === 'videoinput');
      if (settings.mode === 'always') out.splice(first < 0 ? out.length : first, 0, info); // listed first
      else out.push(info);
      return out;
    });
  }

  // Legacy callback-style API used by some older sites.
  for (const name of ['getUserMedia', 'webkitGetUserMedia', 'mozGetUserMedia']) {
    const legacy = navigator[name];
    if (typeof legacy !== 'function') continue;
    try {
      define(navigator, name, function (constraints, onOk, onFail) {
        if (shouldVirtualize(constraints)) { md.getUserMedia(constraints).then(onOk, onFail); return; }
        return legacy.call(navigator, constraints, onOk, onFail);
      });
    } catch (err) { /* leave the legacy API untouched */ }
  }

  /* ----------------------------------------------------------------------- UI */

  const CSS = `
    :host { all: initial; }
    [hidden] { display: none !important; }
    *, *::before, *::after { box-sizing: border-box; }
    .wrap { --bg:#f6f8f9; --fg:#18222b; --muted:#5a6b78; --line:#cfd8de; --accent:#0e7c86; --accent-fg:#fff;
            font: 13px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; color: var(--fg);
            display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
    @media (prefers-color-scheme: dark) {
      .wrap { --bg:#1a242d; --fg:#e8eef2; --muted:#9db0bd; --line:#34444f; --accent:#4fc3cd; --accent-fg:#0b1a1d; }
    }
    button { font: inherit; color: inherit; cursor: pointer; }
    button:focus-visible, input:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
    .chip { display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 999px;
            background: var(--bg); border: 1px solid var(--line); box-shadow: 0 2px 10px rgba(0,0,0,.2); }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #d19a2a; }
    .dot.live { background: #2fa866; }
    .panel { width: 280px; padding: 14px; border-radius: 12px; background: var(--bg); border: 1px solid var(--line);
             box-shadow: 0 8px 28px rgba(0,0,0,.28); display: grid; gap: 10px; }
    .panel.drag { outline: 2px dashed var(--accent); outline-offset: -6px; }
    header { display: flex; align-items: baseline; gap: 8px; }
    header strong { font-size: 14px; }
    .sub { color: var(--muted); flex: 1; }
    .x { border: 0; background: none; font-size: 18px; line-height: 1; padding: 2px 6px; border-radius: 6px; }
    .status { margin: 0; color: var(--muted); word-break: break-word; }
    .row { display: flex; gap: 8px; }
    .btn { padding: 7px 12px; border-radius: 8px; border: 1px solid var(--line); background: transparent; }
    .btn.primary { flex: 1; background: var(--accent); color: var(--accent-fg); border-color: var(--accent); font-weight: 600; }
    .btn:disabled { opacity: .5; cursor: default; }
    .check { display: flex; align-items: center; gap: 6px; color: var(--muted); }
    .link { justify-self: start; border: 0; background: none; padding: 0; color: var(--accent); text-decoration: underline; }
    .hint { margin: 0; color: var(--muted); font-size: 12px; }
  `;

  const ui = (() => {
    let host = null, chip, dot, panel, status, toggle, forget, remember;
    let open = false, autoOpened = false, message = '';

    const suppressed = () => {
      try { return window.top !== window && (innerWidth < 320 || innerHeight < 240); } catch (e) { return true; }
    };

    // Built with DOM calls only (no innerHTML), so it works on pages that enforce Trusted Types.
    const el = (tag, props = {}, ...kids) => {
      const n = document.createElement(tag);
      for (const [k, v] of Object.entries(props)) {
        if (k === 'class') n.className = v;
        else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
        else if (v === true) n.setAttribute(k, '');
        else if (v !== false && v != null) n.setAttribute(k, v);
      }
      n.append(...kids);
      return n;
    };

    const fmt = (s) => (isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '');

    async function pick(file) {
      if (!file) return;
      if (!/^video\//.test(file.type) && !/\.(mp4|m4v|webm|mov|mkv|ogv)$/i.test(file.name)) {
        message = 'That doesn’t look like a video file.'; return update();
      }
      message = 'Loading…'; update();
      try { await loadBlob(file, { name: file.name, persist: remember.checked }); message = ''; }
      catch (err) { message = err.message; }
      update();
    }

    async function forgetSaved() {
      try { await idbDel(); } catch (err) { /* ignore */ }
      src.saved = false; message = 'Saved video removed from this site.'; update();
    }

    function build() {
      host = el('div', { 'data-simo-lqwada': '' });
      host.style.cssText = 'all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647;';
      const root = host.attachShadow({ mode: 'closed' });

      const file = el('input', { type: 'file', accept: 'video/*,.mkv,.mov,.mp4,.webm', hidden: true,
        onchange: () => { pick(file.files[0]); file.value = ''; } });
      dot = el('span', { class: 'dot' });
      chip = el('button', { class: 'chip', type: 'button', 'aria-expanded': 'false', onclick: () => setOpen(!open) },
        dot, el('span', {}, 'simo-lqwada'));
      status = el('p', { class: 'status', 'aria-live': 'polite' });
      toggle = el('button', { class: 'btn', type: 'button',
        onclick: () => { if (vid.paused) { userPaused = false; playVideo(); } else { userPaused = true; vid.pause(); } } }, 'Pause');
      remember = el('input', { type: 'checkbox', checked: true });
      forget = el('button', { class: 'link', type: 'button', onclick: forgetSaved }, 'Remove saved video');
      panel = el('section', { class: 'panel', 'aria-label': 'simo-lqwada virtual camera' },
        el('header', {}, el('strong', {}, 'simo-lqwada'), el('span', { class: 'sub' }, 'Virtual camera'),
          el('button', { class: 'x', type: 'button', 'aria-label': 'Collapse panel', onclick: () => setOpen(false) }, '×')),
        status,
        el('div', { class: 'row' },
          el('button', { class: 'btn primary', type: 'button', onclick: () => file.click() }, 'Choose video…'), toggle),
        el('label', { class: 'check' }, remember, 'Remember on this site'),
        forget,
        el('p', { class: 'hint' }, 'You can also drop a video file here.'));
      panel.addEventListener('dragover', (e) => { e.preventDefault(); panel.classList.add('drag'); });
      panel.addEventListener('dragleave', () => panel.classList.remove('drag'));
      panel.addEventListener('drop', (e) => { e.preventDefault(); panel.classList.remove('drag'); pick(e.dataTransfer.files[0]); });

      const style = el('style'); style.textContent = CSS;
      root.append(style, el('div', { class: 'wrap' }, panel, chip, file));
    }

    function setOpen(v) {
      open = v;
      if (panel) { panel.hidden = !open; chip.setAttribute('aria-expanded', String(open)); }
    }

    function update() {
      if (!host) return;
      toggle.textContent = vid.paused ? 'Play' : 'Pause';
      toggle.disabled = !src.ready;
      forget.hidden = !src.saved;
      dot.classList.toggle('live', src.ready && !vid.paused);
      if (message) status.textContent = message;
      else if (src.ready) {
        status.textContent = `${vid.paused ? 'Paused' : 'Streaming'}: ${src.name} (${fmt(vid.duration)})`;
      } else status.textContent = 'No video selected. Sites see a test pattern until you choose one.';
    }

    function show({ expand = false, force = false } = {}) {
      if (suppressed()) return;
      if (!host) build();
      const root = document.documentElement;
      if (!root) { document.addEventListener('DOMContentLoaded', () => show({ expand, force }), { once: true }); return; }
      if (!host.isConnected) root.appendChild(host);
      if (force) setOpen(true);
      else if (expand && !autoOpened) { autoOpened = true; setOpen(true); }
      else setOpen(open);
      update();
    }

    return { show, update };
  })();

  window.dispatchEvent(new CustomEvent(`${NS}:ready`));
})();
